import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		System.out.println("sum,diff,mul,quo");
		Scanner sc=new Scanner(System.in);
		System.out.println("enter num1:");
		int num1=sc.nextInt();
		Scanner obj=new Scanner(System.in);
		System.out.println("enter num2:");
		int num2=obj.nextInt();
		System.out.println("add of two numbers:"+(num1+num2));
		System.out.println("sub of two numbers:"+(num1-num2));
		System.out.println("mul of two numbers:"+(num1*num2));
		System.out.println("quo of two numbers:"+(num1+num2));
	}
}
